<?php
/**
 * Post single content
 *
 * @package OceanWP WordPress theme
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<?php do_action( 'ocean_before_single_post_content' ); ?>

<div class="entry-content clr"<?php oceanwp_schema_markup( 'entry_content' ); ?>>
	<?php
	the_content();

	wp_link_pages(
		array(
			'before'      => '<div class="page-links">' . __( 'Pages:', 'oceanwp' ),
			'after'       => '</div>',
			'link_before' => '<span class="page-number">',
			'link_after'  => '</span>',
		)
	);

	$posts_per_page = 16;
		$queryOptions = array(
			'posts_per_page' => $posts_per_page,
			'post_type' => 'tribe_events',
			'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
			'orderby' => 'meta_value_num',
			'order' => 'ASC',
			'meta_query' => array(
				array(
					'key'     => '_EventStartDate',
					'value'   =>  '2021-01-01 00:00:00', //date('Y-m-d H:i:s'),
					'compare' => '>=',
				),
			)
		);

		start_pager_hack($queryOptions);
	?>

<?php if (have_posts()) : ?>
	<div class="fy-events-wrap">
			<div class="events-list">
				<div class="events-row">
					<?php while (have_posts()) :
						the_post();
						$event = tribe_get_event(get_the_ID());


						$teacher = array(
							'name' => '',
							'avatar' => wp_get_attachment_image(1135)
						);

						$linked_teacher = get_field('insegnante', get_the_ID());

						if (!empty($linked_teacher)) {
							$teacher = array(
								'name' => $linked_teacher->post_title,
								'avatar' => get_the_post_thumbnail($linked_teacher->ID)
							);
						} else {
							$teacher_name = get_field('nome_insegnante', get_the_ID());

							if (!empty($teacher_name)) {
								$teacher = array(
									'name' => $teacher_name,
									'avatar' => wp_get_attachment_image(get_field('immagine_insegnante', get_the_ID()))
								);
							}
						}



						$event_data = array(
							'title' => get_the_title(),
							'teacher' => $teacher
						);


						$event_timestamp = 	strtotime($event->start_date);

						$event_venue = false;
						$coordinates = false;

						if (!empty($event->venues->all())) {
							$venues = $event->venues->all();
							$event_venue = tribe_get_venue_object($venues[0]);
							$coordinates = tribe_get_coordinates($event_venue);
						}

					?>
						<div class="event">
							<div class="event__img">
								<?php the_post_thumbnail(null, 'medium'); ?>
							</div>
							<div class="event__data">
								<div class="event-teacher">
									<div class="event-teacher__avatar"><?php echo $teacher['avatar']; ?></div>
									<div class="event-teacher__name"><?php echo $teacher['name']; ?></div>
								</div>
							</div>
							<h3 class="event__name"><?php echo $event_data['title']; ?></h3>
							<div class="event__meta">
								<div class="event__date-wrapper meta">
									<i class="eicon-calendar"></i><time datetime="<?php echo $event->start_date; ?>"><?php echo date_i18n('l, j M Y', $event_timestamp) . ' alle ' . date_i18n('H:i', $event_timestamp); ?> </time>
								</div>

								<?php if (!empty($event_venue)) : ?>
									<div class="event__date-wrapper meta">
										<?php if ($coordinates['lat'] != 0 && $coordinates['lng'] != 0) : ?><a href="https://www.google.com/maps/dir/<?php echo $coordinates['lat'] . ',' . $coordinates['lng']; ?>" class="event__geolocation" target="_blank"><?php endif; ?>
											<i class="eicon-map-pin"></i>
											<p class="event_venue"><?php echo $event_venue->address  . ', ' . $event_venue->city; ?></p>
											<?php if ($coordinates['lat'] != 0 && $coordinates['lng'] != 0) : ?>
											</a><?php endif; ?>
									</div>
								<?php endif; ?>

								<div class="event__excerpt">
									<?php the_excerpt() ?>
								</div>
								<div class="fy-buttons">
									<a href="<?php the_permalink(); ?>" class="fy-button--empty">
										<span><?php _e('Scopri di più', 'futureyoga'); ?></span>
									</a>
								</div>
							</div>
						</div>

					<?php endwhile; ?>
				</div>
			</div>
		</div>
			<?php the_posts_pagination(); ?>
		<?php else : ?>

			<p class="text-center"><?php _e('Spiacente nessun evento trovato...', 'futureyoga'); ?></p>

<?php endif; end_pager_hack();
			wp_reset_query(); ?>



</div><!-- .entry -->

<?php do_action( 'ocean_after_single_post_content' ); ?>
